/****** Object:  StoredProcedure [dbo].[GenerateRDInterst_WithPaymentFrequency]    Script Date: 6/3/2019 2:30:10 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GenerateRDInterst_WithPaymentFrequency]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GenerateRDInterst_WithPaymentFrequency]
GO
/****** Object:  StoredProcedure [dbo].[GenerateRDInterst_WithCompounding]    Script Date: 6/3/2019 2:30:10 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GenerateRDInterst_WithCompounding]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[GenerateRDInterst_WithCompounding]
GO
/****** Object:  StoredProcedure [dbo].[GenerateRDInterst_WithCompounding]    Script Date: 6/3/2019 2:30:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GenerateRDInterst_WithCompounding]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GenerateRDInterst_WithCompounding] AS' 
END
GO
/*
BEGIN TRAN
EXEC GenerateRDInterst @Date='2020-5-1'
ROLLBACK
*/
ALTER PROCEDURE [dbo].[GenerateRDInterst_WithCompounding]
	@Date DATE
AS
BEGIN
	BEGIN TRY
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @AccountId INT,
				@QAccountId INT,
				@MonthStartDate DATE,
				@TotalAmount DECIMAL(18,2),
				@QuarterId INT,
				@CompoundFrequency DECIMAL(18,2),
				@Interest DECIMAL(18,2),
				@InterestRate DECIMAL(18,2),
				@BranchId INT,
				@FaildUpdates INT=0,
				@AccountType INT,
				@InstallmentId INT,
				@MonthEndDate DATE,
				@AccountBalance DECIMAL(18,2),
				@MaturityAmount DECIMAL(18,2),
				@InterestFrequency DECIMAL(18,2),
				@PreviousInterest DECIMAL(18,2),
				@OpeningDate DATE,
				@InterestMonth INT,
				@InterestMaxDate DATE

		DECLARE @AdminId INT=(SELECT TOP 1 Id FROM Users WHERE UserName='admin')

		CREATE TABLE #Accounts
		(
			BranchId INT,
			AccountId INT,
			InterestFrequency INT,
			InterestRate DECIMAL(18,2),
			AccountType INT,
			AccountBalance DECIMAL(18,2),
			MaturityAmount DECIMAL(18,2),
			CompoundFrequency INT,
			OpeningDate DATE
		)
		CREATE TABLE #Transactions
		(
			Id INT IDENTITY (1,1),
			InstallmentId INT,
			AccountId INT,
			AccountHistoryId INT,
			Amount INT,
			DueDate DATE
		)
		CREATE TABLE #Quarters
		(
			Id INT IDENTITY (1,1),
			AccountId INT,
			DueDate DATE,
			MonthStartDate DATE,
			TotalAmount DECIMAL(18,2),
			Interest DECIMAL(18,2),
			InstallmentId INT,
			MonthEndDate DATE
		)

		INSERT INTO #Accounts(AccountId,InterestFrequency,InterestRate,BranchId,AccountType,AccountBalance,MaturityAmount,CompoundFrequency,OpeningDate)
		SELECT DISTINCT AccountId,InterestFrequency,InterestRate,BranchId,AccountType,AccountBalance,MaturityAmount,CompoundFrequency,OpeningDate FROM
		(
			SELECT AccountId=ma.Id,
			InterestFrequency=3,--CASE s.CompoundFrequency WHEN 12 THEN 1 WHEN 4 THEN 3 WHEN 2 THEN 6 WHEN 1 THEN 12 END,
			InterestRate=s.InterestRate,BranchId=ma.BranchId,
			AccountType=ma.AccountType,
			RN=ROW_NUMBER() OVER (PARTITION BY ma.Id ORDER BY ih.DueDate ASC),
			AccountBalance=mab.Amount,
			MaturityAmount=ma.MaturityAmount,
			CompoundFrequency=CASE s.CompoundFrequency WHEN 12 THEN 1 WHEN 4 THEN 3 WHEN 2 THEN 6 WHEN 1 THEN 12 END,
			OpeningDate=ma.OpenDate
			FROM InstallmentHistory ih
			INNER JOIN MemberAccounts ma ON ma.Id=ih.AccountId
			INNER JOIN Schemes s ON s.Id=ma.SchemeId
			INNER JOIN MemberAccountBalance mab ON mab.AccountId=ma.Id
			WHERE ma.AccountType =1 AND ISNULL(ih.IsInterestGenerated,0)=0 AND ISNULL(ma.IsActive,0)=1 
			AND ih.DueDate<@Date AND ISNULL(ih.IsActive,0)=1 AND ma.Id=563
		) AS A WHERE A.RN>=InterestFrequency
		--select * from #Accounts
		WHILE EXISTS(SELECT 1 FROM #Accounts)
		BEGIN
			BEGIN TRY
				BEGIN TRAN 
					SELECT TOP 1 @AccountId =AccountId,@InterestFrequency=InterestFrequency,@InterestRate=InterestRate,
					@BranchId=BranchId ,@AccountType=AccountType,@MaturityAmount=MaturityAmount,@AccountBalance=AccountBalance,
					@CompoundFrequency=CompoundFrequency,@OpeningDate=OpeningDate
					FROM #Accounts

					SET @CompoundFrequency = 3

					TRUNCATE TABLE #Transactions
					TRUNCATE TABLE #Quarters

					INSERT INTO #Transactions (InstallmentId,AccountId,AccountHistoryId,Amount,DueDate)
					SELECT ih.Id,ih.AccountId,ih.AccountHistoryId,ih.Amount,ih.DueDate FROM InstallmentHistory ih
					WHERE ISNULL(ih.IsActive,0)=1 AND ih.AccountId=@AccountId AND ih.DueDate<@Date AND ISNULL(ih.IsInterestGenerated,0)=0
					ORDER BY ih.DueDate ASC

					SELECT * FROM #Transactions

					INSERT INTO #Quarters (AccountId,DueDate,MonthStartDate,InstallmentId,MonthEndDate)
					SELECT T.AccountId,T.DueDate,DATEADD(MONTH, DATEDIFF(MONTH, 0, T.DueDate), 0) ,InstallmentId,DATEADD(D, -1, DATEADD(M, DATEDIFF(M, 0, T.DueDate) + 1, 0))
					FROM #Transactions T
					WHERE T.Id%@InterestFrequency=0

					SELECT * FROM #Quarters
					WHILE EXISTS(SELECT 1 FROM #Quarters)
					BEGIN
						SELECT TOP 1 @QuarterId =Id,@QAccountId=AccountId,@MonthStartDate=MonthStartDate,@InstallmentId=InstallmentId,
						@MonthEndDate=MonthEndDate
						FROM #Quarters ORDER BY Id ASC

						SET @InterestMonth = DATEDIFF(MONTH,@OpeningDate,@MonthEndDate)+1
						--SET @InterestMaxDate = DATEADD(DAY,1,CASE WHEN @InterestMonth%@CompoundFrequency=0 THEN DATEADD(MONTH,-@CompoundFrequency,@MonthEndDate)
						--									WHEN @InterestMonth%3=0 THEN DATEADD(MONTH,-(@CompoundFrequency-3),@MonthEndDate)
						--								END)
						SET @InterestMaxDate = DATEADD(DAY,1,CASE WHEN @InterestMonth%@CompoundFrequency=0 THEN DATEADD(MONTH,-@CompoundFrequency,@MonthEndDate)
															ELSE DATEADD(MONTH,-(@InterestMonth%@CompoundFrequency),@MonthEndDate)
														END)
						SET @TotalAmount = ISNULL((SELECT SUM(Amount) FROM InstallmentHistory WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND DueDate<@MonthStartDate),0)
						SET @PreviousInterest = ISNULL((SELECT SUM(Amount) FROM MemberAccountHistory WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND ISNULL(IsInterest,0)=1 
													AND TransactionDate BETWEEN @OpeningDate AND @InterestMaxDate),0)
						SET @TotalAmount = ISNULL(@TotalAmount,0) + ISNULL(@PreviousInterest,0)
						
						IF(ISNULL(@TotalAmount,0)>0)
						BEGIN
							SET @Interest = (@TotalAmount*@InterestRate/CAST(100 AS DECIMAL(18,2)))*(@InterestFrequency/CAST(12 AS DECIMAL(18,2)))

							SELECT InterestMonth=@InterestMonth,TotalAmount=@TotalAmount,PreviousInterest=@PreviousInterest,Interest=@Interest ,InterestMaxDate=@InterestMaxDate

							IF(ISNULL(@Interest,0)>0)
							BEGIN
								IF(ISNULL(@Interest,0) + ISNULL(@AccountBalance,0)>ISNULL(@MaturityAmount,0))
								BEGIN
									SET @Interest = ISNULL(@MaturityAmount,0)-ISNULL(@AccountBalance,0)
								END
								IF(ISNULL(@Interest,0)>0)
								BEGIN
									UPDATE MemberAccountBalance SET Amount=Amount+@Interest,ModifiedOn=GETUTCDATE(),InterestCalculationDate=@MonthEndDate WHERE AccountId=@QAccountId

									INSERT INTO MemberAccountHistory (BranchId,AccountId,TransactionTypeId,PaymentModeId,TransactionDate,TransactionDetail,IsInterest,Amount,CreatedOn,CreatedBy,IsActive,Remark)
									VALUES (@BranchId,@QAccountId,1,3,@MonthEndDate,'',1,@Interest,GETUTCDATE(),@AdminId ,1,'INTEREST')

									UPDATE InstallmentHistory SET IsInterestGenerated=1 WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND Id<=@InstallmentId
								END
							END
						END

						select * from MemberAccountBalance where AccountId=@QAccountId

						DELETE FROM #Quarters WHERE Id=@QuarterId
					END
				ROLLBACK
					DELETE FROM #Accounts WHERE AccountId=@AccountId
				--COMMIT TRAN
				
			END TRY
			BEGIN CATCH
				ROLLBACK
				DELETE FROM #Accounts WHERE AccountId=@AccountId
				EXEC StoreErrorInfo      
				SET @FaildUpdates=@FaildUpdates+1
			END CATCH
		END

		DROP TABLE #Accounts
		DROP TABLE #Transactions
		DROP TABLE #Quarters

		SELECT ReturnValue=@FaildUpdates,ErrorMessage = ''
		RETURN 0
	END TRY
	BEGIN CATCH
		EXEC StoreErrorInfo      
		SELECT ReturnValue=-1,ErrorMessage = 'Transaction error. Please contact to administrator.'
		RETURN -1
	END CATCH
END



GO
/****** Object:  StoredProcedure [dbo].[GenerateRDInterst_WithPaymentFrequency]    Script Date: 6/3/2019 2:30:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GenerateRDInterst_WithPaymentFrequency]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GenerateRDInterst_WithPaymentFrequency] AS' 
END
GO
/*
BEGIN TRAN
EXEC GenerateRDInterst_WithPaymentFrequency @Date='2020-11-1'
ROLLBACK
*/
ALTER PROCEDURE [dbo].[GenerateRDInterst_WithPaymentFrequency]
	@Date DATE
AS
BEGIN
	BEGIN TRY
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @AccountId INT,
				@QAccountId INT,
				@MonthStartDate DATE,
				@TotalAmount DECIMAL(18,2),
				@QuarterId INT,
				@CompoundFrequency DECIMAL(18,2),
				@Interest DECIMAL(18,2),
				@InterestRate DECIMAL(18,2),
				@BranchId INT,
				@FaildUpdates INT=0,
				@AccountType INT,
				@InstallmentId INT,
				@MonthEndDate DATE,
				@AccountBalance DECIMAL(18,2),
				@MaturityAmount DECIMAL(18,2),
				@InterestFrequency DECIMAL(18,2),
				@PreviousInterest DECIMAL(18,2),
				@OpeningDate DATE,
				@InterestMonth INT,
				@InterestMaxDate DATE,
				@PaymentFrequency INT,
				@TransactionNo INT,
				@InterestCalculationDate DATE

		DECLARE @AdminId INT=(SELECT TOP 1 Id FROM Users WHERE UserName='admin')

		CREATE TABLE #Accounts
		(
			BranchId INT,
			AccountId INT,
			InterestFrequency INT,
			InterestRate DECIMAL(18,2),
			AccountType INT,
			AccountBalance DECIMAL(18,2),
			MaturityAmount DECIMAL(18,2),
			CompoundFrequency INT,
			OpeningDate DATE,
			PaymentFrequency INT,
			InterestCalculationDate	DATE
		)
		CREATE TABLE #Transactions
		(
			Id INT IDENTITY (1,1),
			InstallmentId INT,
			AccountId INT,
			AccountHistoryId INT,
			Amount INT,
			DueDate DATE,
			TransactionNo INT,
			InterestGenerationCount INT
		)
		CREATE TABLE #Quarters
		(
			Id INT IDENTITY (1,1),
			AccountId INT,
			DueDate DATE,
			MonthStartDate DATE,
			TotalAmount DECIMAL(18,2),
			Interest DECIMAL(18,2),
			InstallmentId INT,
			MonthEndDate DATE,
			TransactionNo INT
		)
		DECLARE @Numbers TABLE 
		(
		    Number INT PRIMARY KEY
		)
		DECLARE @Start INT=1,
				@End INT=12
		WHILE (@Start<=@End)
		BEGIN
			INSERT INTO @Numbers VALUES(@Start)
			SET @Start=@Start+1
		END

		INSERT INTO #Accounts(AccountId,InterestFrequency,InterestRate,BranchId,AccountType,AccountBalance,MaturityAmount,CompoundFrequency,OpeningDate,PaymentFrequency,InterestCalculationDate)
		SELECT DISTINCT AccountId,InterestFrequency,InterestRate,BranchId,AccountType,AccountBalance,MaturityAmount,CompoundFrequency,OpeningDate,PaymentFrequency,InterestCalculationDate FROM
		(
			SELECT AccountId=ma.Id,
			InterestFrequency=3,--CASE s.CompoundFrequency WHEN 12 THEN 1 WHEN 4 THEN 3 WHEN 2 THEN 6 WHEN 1 THEN 12 END,
			InterestRate=s.InterestRate,BranchId=ma.BranchId,
			AccountType=ma.AccountType,
			RN=ROW_NUMBER() OVER (PARTITION BY ma.Id ORDER BY DATEADD(MONTH,(n.Number-1),ih.DueDate) ASC),
			AccountBalance=mab.Amount,
			MaturityAmount=ma.MaturityAmount,
			CompoundFrequency=CASE s.CompoundFrequency WHEN 12 THEN 1 WHEN 4 THEN 3 WHEN 2 THEN 6 WHEN 1 THEN 12 END,
			OpeningDate=ma.OpenDate,
			PaymentFrequency=t.PaymentFrequency,
			InterestCalculationDate=mab.InterestCalculationDate
			FROM InstallmentHistory ih
			INNER JOIN MemberAccounts ma ON ma.Id=ih.AccountId
			INNER JOIN Schemes s ON s.Id=ma.SchemeId
			INNER JOIN MemberAccountBalance mab ON mab.AccountId=ma.Id
			CROSS APPLY(SELECT PaymentFrequency=12) t--CASE WHEN ISNULL(ma.PaymentFrequency,0)=0 THEN 1 ELSE ma.PaymentFrequency END) t
			CROSS APPLY(SELECT n.Number FROM @Numbers n WHERE n.Number<=t.PaymentFrequency) n
			WHERE ma.AccountType =1 AND ISNULL(ih.IsInterestGenerated,0)=0 AND ISNULL(ma.IsActive,0)=1 
			AND DATEADD(MONTH,(n.Number-1),ih.DueDate)<@Date AND ISNULL(ih.IsActive,0)=1 AND ma.Id=2451
			AND (t.PaymentFrequency=1 OR DATEADD(MONTH,((ISNULL(ih.InterestGenerationCount,0)*t.PaymentFrequency)-1),ih.DueDate)<@Date)
		) AS A WHERE A.RN>=InterestFrequency
		select * from #Accounts
		WHILE EXISTS(SELECT 1 FROM #Accounts)
		BEGIN
			BEGIN TRY
				BEGIN TRAN 
					SELECT TOP 1 @AccountId =AccountId,@InterestFrequency=InterestFrequency,@InterestRate=InterestRate,
					@BranchId=BranchId ,@AccountType=AccountType,@MaturityAmount=MaturityAmount,@AccountBalance=AccountBalance,
					@CompoundFrequency=CompoundFrequency,@OpeningDate=OpeningDate,@PaymentFrequency=PaymentFrequency,
					@InterestCalculationDate=InterestCalculationDate
					FROM #Accounts
					
					SET @CompoundFrequency = 3

					TRUNCATE TABLE #Transactions
					TRUNCATE TABLE #Quarters

					INSERT INTO #Transactions (InstallmentId,AccountId,AccountHistoryId,Amount,DueDate,TransactionNo,InterestGenerationCount)
					SELECT ih.Id,ih.AccountId,ih.AccountHistoryId,ih.Amount/@PaymentFrequency,DATEADD(MONTH,(n.Number-1),ih.DueDate),n.Number,
					ISNULL(ih.InterestGenerationCount,1)
					FROM InstallmentHistory ih
					CROSS APPLY(SELECT n.Number FROM @Numbers n WHERE n.Number<=@PaymentFrequency) n
					WHERE ISNULL(ih.IsActive,0)=1 AND ih.AccountId=@AccountId AND DATEADD(MONTH,(n.Number-1),ih.DueDate)<@Date AND ISNULL(ih.IsInterestGenerated,0)=0
					ORDER BY ih.DueDate ASC

					SELECT * FROM #Transactions

					INSERT INTO #Quarters (AccountId,DueDate,MonthStartDate,InstallmentId,MonthEndDate,TransactionNo)
					SELECT T.AccountId,T.DueDate,DATEADD(MONTH, DATEDIFF(MONTH, 0, T.DueDate), 0) ,InstallmentId,
					DATEADD(D, -1, DATEADD(M, DATEDIFF(M, 0, T.DueDate) + 1, 0)),T.TransactionNo
					FROM #Transactions T
					WHERE T.Id%@InterestFrequency=0 AND (@PaymentFrequency=1 OR T.Id > (T.InterestGenerationCount*@InterestFrequency))

					SELECT * FROM #Quarters
					WHILE EXISTS(SELECT 1 FROM #Quarters)
					BEGIN
						SELECT TOP 1 @QuarterId =Id,@QAccountId=AccountId,@MonthStartDate=MonthStartDate,@InstallmentId=InstallmentId,
						@MonthEndDate=MonthEndDate,@TransactionNo=TransactionNo
						FROM #Quarters ORDER BY Id ASC

						SET @InterestMonth = DATEDIFF(MONTH,@OpeningDate,@MonthEndDate)+1
						--SET @InterestMaxDate = DATEADD(DAY,1,CASE WHEN @InterestMonth%@CompoundFrequency=0 THEN DATEADD(MONTH,-@CompoundFrequency,@MonthEndDate)
						--									WHEN @InterestMonth%3=0 THEN DATEADD(MONTH,-(@CompoundFrequency-3),@MonthEndDate)
						--								END)
						SET @InterestMaxDate = DATEADD(DAY,1,CASE WHEN @InterestMonth%@CompoundFrequency=0 THEN DATEADD(MONTH,-@CompoundFrequency,@MonthEndDate)
															ELSE DATEADD(MONTH,-(@InterestMonth%@CompoundFrequency),@MonthEndDate)
														END)
						SET @TotalAmount = ISNULL((SELECT SUM(Amount) FROM InstallmentHistory WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND DueDate<@MonthStartDate),0)
						SET @PreviousInterest = ISNULL((SELECT SUM(Amount) FROM MemberAccountHistory WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND ISNULL(IsInterest,0)=1 
													AND TransactionDate BETWEEN @OpeningDate AND @InterestMaxDate),0)
						SET @TotalAmount = ISNULL(@TotalAmount,0) + ISNULL(@PreviousInterest,0)
						
						IF(ISNULL(@TotalAmount,0)>0)
						BEGIN
							SET @Interest = (@TotalAmount*@InterestRate/CAST(100 AS DECIMAL(18,2)))*(@InterestFrequency/CAST(12 AS DECIMAL(18,2)))

							SELECT InterestMonth=@InterestMonth,TotalAmount=@TotalAmount,PreviousInterest=@PreviousInterest,Interest=@Interest ,InterestMaxDate=@InterestMaxDate

							IF(ISNULL(@Interest,0)>0)
							BEGIN
								IF(ISNULL(@Interest,0) + ISNULL(@AccountBalance,0)>ISNULL(@MaturityAmount,0))
								BEGIN
									SET @Interest = ISNULL(@MaturityAmount,0)-ISNULL(@AccountBalance,0)
								END
								IF(ISNULL(@Interest,0)>0)
								BEGIN
									UPDATE MemberAccountBalance SET Amount=Amount+@Interest,ModifiedOn=GETUTCDATE(),InterestCalculationDate=@MonthEndDate WHERE AccountId=@QAccountId

									INSERT INTO MemberAccountHistory (BranchId,AccountId,TransactionTypeId,PaymentModeId,TransactionDate,TransactionDetail,IsInterest,Amount,CreatedOn,CreatedBy,IsActive,Remark)
									VALUES (@BranchId,@QAccountId,1,3,@MonthEndDate,'',1,@Interest,GETUTCDATE(),@AdminId ,1,'INTEREST')

									IF(@PaymentFrequency=1)
									BEGIN
										UPDATE InstallmentHistory SET IsInterestGenerated=1 WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND Id<=@InstallmentId
									END
									ELSE 
									BEGIN
										UPDATE InstallmentHistory SET InterestGenerationCount=ISNULL(InterestGenerationCount,0)+1 WHERE AccountId=@QAccountId AND ISNULL(IsActive,0)=1 AND Id<=@InstallmentId
									END
								END
							END
						END

						select * from MemberAccountBalance where AccountId=@QAccountId
						--select * from InstallmentHistory where AccountId=@QAccountId
						DELETE FROM #Quarters WHERE Id=@QuarterId
					END
				ROLLBACK
					DELETE FROM #Accounts WHERE AccountId=@AccountId
				--COMMIT TRAN
				
			END TRY
			BEGIN CATCH
				ROLLBACK
				DELETE FROM #Accounts WHERE AccountId=@AccountId
				EXEC StoreErrorInfo      
				SET @FaildUpdates=@FaildUpdates+1
			END CATCH
		END

		DROP TABLE #Accounts
		DROP TABLE #Transactions
		DROP TABLE #Quarters

		SELECT ReturnValue=@FaildUpdates,ErrorMessage = ''
		RETURN 0
	END TRY
	BEGIN CATCH
		EXEC StoreErrorInfo      
		SELECT ReturnValue=-1,ErrorMessage = 'Transaction error. Please contact to administrator.'
		RETURN -1
	END CATCH
END



GO
