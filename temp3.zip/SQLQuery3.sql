BEGIN TRAN
	DECLARE @AccountNo VARCHAR(100)='1090000002',
			@BankAccountId INT=2168,
			@AccountId INT=0,
			@Message VARCHAR(100)='SUCCESS',
			@AccountHistoryId INT=0,
			@BranchId INT=1,
			@VoucherId INT,
			@Amount DECIMAL(18,2)
	
	
	SET @AccountId = (SELECT Id FROM MemberAccounts WHERE AccountNo=@AccountNo AND AccountType=7)
	SELECT @AccountHistoryId=Id,@Amount=Amount FROM MemberAccountHistory WHERE AccountId=@AccountId AND IsActive=1 AND TransactionTypeId=1 AND PaymentModeId IN (2,3)
	
	IF (ISNULL(@AccountId,0)=0)
	BEGIN
		SET @Message = 'Invalid Account.'
	END
	ELSE IF (ISNULL(@AccountHistoryId,0)=0)
	BEGIN
		SET @Message = 'Invalid Account History.'
	END
	ELSE IF NOT EXISTS(SELECT 1 FROM BranchBalanceHistory WHERE AccountHistoryId=@AccountHistoryId AND IsActive=1)
	BEGIN
		SET @Message = 'Invalid Cash History.'
	END
	ELSE
	BEGIN
		UPDATE BranchBalanceHistory SET IsActive=0 WHERE AccountHistoryId=@AccountHistoryId AND IsActive=1
		UPDATE BranchBalance SET Amount=Amount+@Amount WHERE BranchId=@BranchId
	
		INSERT INTO Vouchers (BranchId,VoucherDate,DebitAccountId,CreditAccountId,Amount,VoucherDetail,CreatedOn,IsActive,IsHidden)
		SELECT TOP 1 BranchId,TransactionDate,@AccountId,@BankAccountId,Amount,Remark,CreatedOn,IsActive,1
		FROM MemberAccountHistory WHERE Id=@AccountHistoryId
	
		SET @VoucherId = SCOPE_IDENTITY()
	
		INSERT INTO MemberAccountHistory (BranchId,AccountId,TransactionTypeId,PaymentModeId,TransactionDate,TransactionDetail,
											Amount,Remark,CreatedOn,CreatedBy,IsActive,VoucherId,BalanceAffect)
		SELECT TOP 1 BranchId,@BankAccountId,2,PaymentModeId,TransactionDate,TransactionDetail,Amount,Remark,CreatedOn,CreatedBy,IsActive,@VoucherId,2
		FROM MemberAccountHistory WHERE Id=@AccountHistoryId
	
		UPDATE MemberAccountBalance SET Amount=Amount-@Amount WHERE AccountId=@BankAccountId
	
		UPDATE MemberAccountHistory SET VoucherId=@VoucherId WHERE Id=@AccountHistoryId
	END
	SELECT Msg=@Message
	--exec GetDayBook 1,'2018-05-18','2018-05-18',1,1000000,0,0,1
--ROLLBACK
COMMIT